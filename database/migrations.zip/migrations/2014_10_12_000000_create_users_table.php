<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->increments('id');
            $table->string('name');
            $table->string('prenom');
            $table->datetime('datenaiss');
            $table->string('telephone')->unique();
            $table->string('numero_cni');
            $table->string('photo');
            $table->string('date_enreg');
            $table->integer('actif');
            $table->string('lien_invitation');
            $table->string('nationalite');
            $table->integer('numero_nw')->default(0);
            $table->integer('nbre_invite')->default(0);
            $table->integer('niveau_reseau')->default(0);
            $table->string('pays');
            $table->string('langue');
            $table->string('ville')->nullable();
            $table->string('region')->nullable();
            $table->string('mon_lien_invitation');
            $table->string('email')->unique();
            $table->string('password');
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
